# Hi there 👋, Bhargavi here. 
![Visitor](https://visitor-badge.laobi.icu/badge?page_id=Bhargavi-hash.repoName) [![GitHub followers](https://img.shields.io/github/followers/Bhargavi-hash.svg?style=social&label=Follow)](https://github.com/Bhargavi-hash?tab=followers)<br/>

<!--
**Bhargavi-hash/Bhargavi-hash** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
-->

<img align="right" width=300px alt="Unicorn" src="https://c.tenor.com/GN73MKBawZYAAAAi/busy-cute.gif" />

## <img src="https://media.giphy.com/media/ObNTw8Uzwy6KQ/giphy.gif" width="30px">&nbsp;***About me***

I am an undergraduate Computer science and Engineering student at IIIT-Hyderabad. C, C++, Python, Javascript, HTML, and Shell are the programming languages I am good at. I love to learn and build something new, productive, innovative and creative.
* **I am interested in Web designing, Android development, and digital marketing**
- 🌱 I’m currently learning ...
  - Java
  - React js
- 👯 I’m looking forward to collaborate on open source projects.
- ✔ Ask me about anything, I am happy to help, only if the ball is in my court!😉<br>
- Outside tech, 📖 I love to read novels, 🖌️ do painting and skecthing, 🎵 listen to music, and 🌴 explore nature outdoors.
- 📫 Reach out to me at: <a href="bhargavi.kurukunda@students.iiit.ac.in">bhargavi.kurukunda@students.iiit.ac.in</a>

__Check out my GitHub repository:__

<div>
  <p>
    <a href="https://github.com/Bhargavi-hash/HotelFranchiseDBMS.git">
      <img src="https://github-readme-stats.vercel.app/api/pin/?username=Bhargavi-hash&repo=HotelFranchiseDBMS" alt="GitHub Stats" />
    </a>
    <a href="https://github.com/Bhargavi-hash/Linux-Shell-Implementation.git">
      <img src="https://github-readme-stats.vercel.app/api/pin/?username=Bhargavi-hash&repo=Linux-Shell-Implementation" alt="GitHub Stats" />
    </a>
  </p>
</div>


<h2>👀 My github Stats</h2>

<div>
<!--   <p align="center">
    <b><em>Now listening to:</em></b> <br/>
    <img src="https://spotify-github-profile.vercel.app/api/view?uid=Bhargavi-hash&cover_image=true&theme=novatorem" alt="Now Listenting to" />
  </p> -->
  
  <p align="center">
  <b><em>GitHub Stats:</em></b> <br/>
    <img src="https://github-readme-streak-stats.herokuapp.com/?user=Bhargavi-hash" alt="GitHub Stats" /> <br/><br/>
  
</div>

![My github status](https://github-readme-stats.vercel.app/api?username=Bhargavi-hash&show_icons=true&include_all_commits=true)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Bhargavi-hash&layout=compact)

---------------------------------------------------------------------------------------------------------------------
Credits: <a href="https://github.com/Bhargavi-hash">Bhargavi-hash</a>

Date: 18/11/2021
