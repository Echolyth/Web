
<h1 align="center">
 👋 Hi, I'm mahmoud miehob!
</h1>
 

<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?size=26&duration=2500&lines=Software+Engineer;laravel+developer;fullstack+developer" > 
</p>


</br> 

<a href="#"><img  width="100%" height="auto" src="https://i.imgur.com/iXuL1HG.png" height="175px"/></a>

</br>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<img align="right" width=200px height=200px alt="side_sticker" src="https://media.giphy.com/media/TEnXkcsHrP4YedChhA/giphy.gif" />

>✔  I’m currently working on freelancer job  <br>
✔  I’m currently learning Everything related with software engineering .. <br>
✔  All of my projects are available at https://github.com/MahmoudMiehob <br>
✔  I regularly write articles on : https://www.facebook.com/profile.php?id=100010194910703 <br>
✔  Ask me about php,laravel framework and all about learning IT in albaath university <br>
✔  How to reach me: <br> &nbsp; &nbsp; * [Facebook-@mahmoudmiehob](https://www.facebook.com/profile.php?id=100010194910703) <br>
                         &nbsp; &nbsp; * [Email-@mahmoudmiehob](mahmoudmiehob@gmail.com) <br>
                         &nbsp; &nbsp; * [linkedIn-@mahmoudmiehob](https://www.linkedin.com/in/mahmoud-miehob-937064187) <br>
✔  Know about my experiences : https://www.linkedin.com/in/mahmoud-miehob-937064187 <br>


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


  <summary><b>⚡ Recent GitHub Activity</b></summary>
  <br/>
   <a href="https://github.com/mahmoudmiehob"><img alt="mahmoud's Activity Graph" src="https://activity-graph.herokuapp.com/graph?username=mahmoudmiehob&custom_title=mahmoudmiehob's%20Contribution%20Graph&theme=react-dark" /></a>
  <br/>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center"><a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=mahmoudmiehob" alt="mahmoud" /></a></p>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


<p align='center'>
<img src="https://media.giphy.com/media/WFZvB7VIXBgiz3oDXE/giphy.gif" width="200" height="200" frameBorder="0" class="giphy-embed" allowFullScreen></img></p>
<br>

```php

<?php


class About extends Me
{

    public function getInfo($name , $age)
    {
	echo "my name is " . $name . " and my age is " . $ago ;
    }
    
    
    public function getCurrentWorkplace()
    {
        return [
            'workplace' => [
                'company' => 'freelancer',
                'position' => 'Home'         
            ]
        ];
    }

    public function getKnowledge()
    {
        return [
	    Html::class,
	    Css::class,
            Php::class,
            Javascript::class,
            Laravel::class,
            Bootstrap::class,
        ];
    }

    public function getFutureGoal()
    {
        return 'To contribute to open source.';
    }
}

?>


```


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


 <h2> 📊 Github Stats ....</h2>
<p align="center">
<img src="http://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=mahmoudmiehob&theme=solarized_dark">
<img src="http://github-profile-summary-cards.vercel.app/api/cards/repos-per-language?username=mahmoudmiehob&theme=solarized_dark">
<img src="http://github-profile-summary-cards.vercel.app/api/cards/most-commit-language?username=mahmoudmiehob&theme=solarized_dark">
<img src="http://github-profile-summary-cards.vercel.app/api/cards/stats?username=mahmoudmiehob&theme=solarized_dark">
<img src="http://github-profile-summary-cards.vercel.app/api/cards/productive-time?username=mahmoudmiehob&theme=solarized_dark&utcOffset=8">
	
</p>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


<h2 align="left"> 💻 Languages and Tools:</h2>

<table align="center">
  <tr>
      <td align="center" width="96">
      <a href="#html5">
        <img src="https://seeklogo.com/images/H/html5-without-wordmark-color-logo-14D252D878-seeklogo.com.png" width="48" height="48" alt="Html5" />
      </a>
      <br>Html5
    </td>
    <td align="center" width="96">
      <a href="#css3">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CSS3_logo.svg/48px-CSS3_logo.svg.png" width="48" height="48" alt="Css3" />
      </a>
      <br>CSS3
    </td>
     <td align="center" width="96">
      <a href="#bootstrap">
        <img src="https://cdn.worldvectorlogo.com/logos/bootstrap-4.svg" width="48" height="48" alt="Bootstrap" />
      </a>
      <br>Bootstrap
    </td>
     <td align="center" width="96">
      <a href="#js">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/1024px-Unofficial_JavaScript_logo_2.svg.png" width="48" height="48" alt="javascript" />
      </a>
      <br>Javascript
    </td>
     <td align="center" width="96">
      <a href="#vuejs">
        <img src="https://www.vectorlogo.zone/logos/vuejs/vuejs-icon.svg" width="48" height="48" alt="Vuejs" />
      </a>
      <br>Vue JS
    </td>
  </tr>

  <tr>
      <td align="center" width="96">
      <a href="#laravel">
        <img src="https://cdn.worldvectorlogo.com/logos/laravel-2.svg" width="48" height="48" alt="Laravel" />
      </a>
      <br>Laravel
    </td>
    <td align="center" width="96">
        <a href="#livewire">
            <img src="https://i0.wp.com/laravel-livewire.com/img/twitter.png" width="48" height="48"
                alt="livewire" />
        </a>
        <br>Livewire
    </td>
      <td align="center" width="96">
      <a href="#laravel">
        <img src="https://www.logo.wine/a/logo/MySQL/MySQL-Logo.wine.svg" width="48" height="48" alt="Laravel" />
      </a>
      <br>MySQL
    </td>
  </tr>
   <tr>
      <td align="center" width="96">
      <a href="#ubuntu" >
        <img src="https://seeklogo.com/images/U/ubuntu-logo-8FDEC6A07B-seeklogo.com.png" width="48" height="48" alt="ubuntu" />
      </a>
      <br>Ubuntu
    </td>
      <td align="center" width="96">
      <a href="#git" >
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Git_icon.svg/1200px-Git_icon.svg.png" width="48" height="48" alt="Git" />
      </a>
      <br>Git
    </td>
      <td align="center"  width="96">
      <a href="#vscode">
        <img src="https://upload.wikimedia.org/wikipedia/commons/9/9a/Visual_Studio_Code_1.35_icon.svg" width="48" height="48" alt="Jamstack" />
      </a>
      <br>VS Code
    </td>
      <td align="center" width="96">
      <a href="#postman" >
        <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" width="48" height="48" alt="Git" />
      </a>
      <br>Postman
    </td>

  </tr>
</table>


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 📊 My Github Stats

<p align="left" style="margin-right:0px;padding-right:0px">
<img src="https://github-readme-stats.vercel.app/api?username=MahmoudMiehob&theme=algolia">
<img alt="streak stats" src="https://github-readme-streak-stats.herokuapp.com/?user=mahmoudmiehob&theme=algolia" />
</p>




## Connect with me:

<p align="center">
  <a href="https://www.linkedin.com/in/mahmoud-miehob-937064187"><img src="https://img.shields.io/badge/linkedin-0077B5.svg?style=for-the-badge&logo=linkedin&logoColor=ffffff"/></a>
   <a href="https://www.facebook.com/profile.php?id=100010194910703"><img src="https://img.shields.io/badge/facebook-1b74e4.svg?style=for-the-badge&logo=facebook&logoColor=ffffff"/></a>
   <a href="mailto:mahmoudmiehob@gmail.com?subject=[GitHub]%20🔥%20profile%20contact&body=Hello"><img src="https://img.shields.io/badge/e‑mail-D14836.svg?style=for-the-badge&logo=GMail&logoColor=ffffff"/></a>
  <a href="https://www.youtube.com/channel/UCuGcIO6rrQkwZr4ex5oaB3w"><img src="https://img.shields.io/badge/youtube-e00101.svg?style=for-the-badge&logo=youtube&logoColor=ffffff"/></a>

</p>

## ❤ Views and Followers

<p align='center'> <img src="https://komarev.com/ghpvc/?username=mahmoudmiehob&label=Profile%20views&color=blueviolet&style=plastic" width="160px" alt="views" /> </p>


<h2 align='left'>Thank You ❤</h2>
<p align="center">
  <img src="https://media.giphy.com/media/jpVnC65DmYeyRL4LHS/giphy.gif" width="70%" height="65px">
</p>	
 
<br>
