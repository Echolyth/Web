<h1 align="center">Hi Geeks, I'm Bright <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="35"></h1>

I am really love to code and learning about programming.

<a target="_blank" align="center">
  <img  top="500" height="300" width="400" alt="GIF" src="https://media.tenor.com/ojvGzDGhAtAAAAAd/enjoying-music-music.gif">
</a>

### :boy: About Me
#

- :office: I’m currently working on [Accenture](https://www.accenture.com/th-en/about/company/thailand).
- 🌱 I’m currently Working on Backend Developer (SpringBoot and Nodejs)
- 🤝 I’m available for freelancing.
- :coffee: [Dev7Days](https://dev7days.gitbook.io/dev7days/) This is my website to summarize what I'm learning about
  programming.
- 📫 How to reach me **dsorn2@gmail.com**
- 📄 Know about my experiences <a href="https://github.com/brightkut/brightkut/blob/main/resumev8.pdf" target="blank">
  Resume</a>

### :open_book: Skills 
#
<div/>
📋 Languages and Framework:
<br/>
<br/>
<!-- html -->
<a margin="20" href="https://developer.mozilla.org/en-US/docs/Web/HTML" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/html.svg" alt="html"></a>
<!-- css -->
<a margin="20" href="https://developer.mozilla.org/en-US/docs/Web/CSS" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/css.svg" alt="css"></a>
<!-- js -->
<a margin="20" href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/javascript.svg" alt="javascript"></a>
<!-- bootstrap -->
<a margin="20" href="https://getbootstrap.com" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/bootstrap.svg" alt="bootstrap"></a>
<!-- saas -->
<a margin="20" href="https://sass-lang.com" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/sass.svg" alt="sass"></a>

<br/>
<!-- react -->
<a margin="20" href="https://reactjs.org" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/react.svg" alt="react"></a>
<!-- mat-ui -->
<a margin="20" href="https://mui.com" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/materialui.svg" alt="material ui"></a>
<!-- nodejs -->
<a margin="20" href="https://nodejs.org" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/nodejs.svg" alt="nodejs"></a>
<!-- express -->
<a margin="20" href="https://expressjs.com" target="_blank"><img margin="20px" height="20" src="https://github.com/abdoachhoubi/abdoachhoubi/blob/main/svgs/express.svg" alt="express"></a>
<!-- ts -->
<a margin="20" href="https://www.typescriptlang.org" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/Typescript_logo_2020-svg.png" alt="ts"></a>

<br/>
<!-- java -->
<a margin="20" href="https://www.java.com/en/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/java.png" alt="java"></a>
<!-- springboot -->
<a margin="20" href="https://spring.io/projects/spring-boot" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/spring.png" alt="springboot"></a>
<!-- nestjs -->
<a margin="20" href="https://nestjs.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/nest.svg" alt="nestjs"></a>
<!-- python -->
<a margin="20" href="https://www.python.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/python.png" alt="python"></a>
<!-- C# -->
<a margin="20" href="https://learn.microsoft.com/en-us/dotnet/csharp/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/Csharp.png" alt="c#"></a>

<br/>
<!-- R -->
<a margin="20" href="https://www.r-project.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/r.png" alt="R"></a>
<!-- kotlin -->
<a margin="20" href="https://kotlinlang.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/kotlin.png" alt="kotlin"></a>
<!-- Shell Script -->
<a margin="20" href="https://www.shellscript.sh/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/sh.png" alt="sh"></a>
<!-- Linux -->
<a margin="20" href="https://www.linux.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/linux.png" alt="linux"></a></div>
<br/>

<div/>
☁️ Cloud:
<br/>
<br/>
<!-- AWS -->
<a margin="20" href="https://aws.amazon.com/th/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/aws.png" alt="aws"></a>
<!-- Heroku -->
<a margin="20" href="https://www.heroku.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/heroku.jpeg" alt="heroku"></a></div>
<br/>
♾️ Tools/DevOps:
<br/>
<br/>
<!-- Docker -->
<a margin="20" href="https://www.docker.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/docker.png" alt="docker"></a>
<!-- Terraform -->
<a margin="20" href="https://www.terraform.io/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/terra.png" alt="terraform"></a>
<!-- K8s -->
<a margin="20" href="https://kubernetes.io/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/k8s.png" alt="k8s"></a>
<!-- Openshift -->
<a margin="20" href="https://www.redhat.com/en/technologies/cloud-computing/openshift" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/opc.png" alt="openshift"></a>
<br/>
<!-- Jenkins -->
<a margin="20" href="https://www.jenkins.io/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/jenkins.png" alt="jenkins"></a>
<!-- Github -->
<a margin="20" href="https://github.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/github.png" alt="github"></a>
<!-- Gitlab -->
<a margin="20" href="https://about.gitlab.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/gitlab.png" alt="gitlab"></a>
<!-- Kafka -->
<a margin="20" href="https://kafka.apache.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/kafka.jpeg" alt="kafka"></a>
<!-- Kibana -->
<a margin="20" href="https://www.elastic.co/what-is/kibana" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/kibana.png" alt="kibana"></a></div>
<br/>

<div/>
💾 Databases:
<br/>
<br/>
<!-- MongoDB -->
<a margin="20" href="https://www.mongodb.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/mongo.png" alt="mongo"></a>
<!-- Mysql -->
<a margin="20" href="https://www.mysql.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/mysql.jpeg" alt="mysql"></a>
<!-- MariaDB -->
<a margin="20" href="https://mariadb.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/maria.jpeg" alt="maria"></a>
<!-- Postgres -->
<a margin="20" href="https://www.postgresql.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/postgres.jpeg" alt="postgres"></a>
<!-- Sqlite -->
<a margin="20" href="https://www.sqlite.org/index.html" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/sqlite.jpeg" alt="sqlite"></a>
<br/>
<!-- DynamoDB -->
<a margin="20" href="https://aws.amazon.com/th/dynamodb/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/dynamo.png" alt="dyanamo"></a>
<!-- Redis -->
<a margin="20" href="https://redis.io/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/redis.jpeg" alt="redis"></a>
<!-- Elastic -->
<a margin="20" href="https://www.elastic.co" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/elastic.png" alt="elastic"></a></div>
<br/>
<div/>
🥅 Testing:
<br/>
<br/>
<!-- RobotFramework -->
<a margin="20" href="https://robotframework.org/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/robot.png" alt="robot"></a></div>

<div/>
<br/>
💻 IDEs/Editors:
<br/>
<br/>
<!-- Notion -->
<a margin="20" href="https://www.notion.so/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/notion.png" alt="notion"></a>
<!-- Postman -->
<a margin="20" href="https://www.postman.com/downloads/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/post.png" alt="postman"></a>
<!-- Sublime -->
<a margin="20" href="https://www.sublimetext.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/sub.jpeg" alt="sublime"></a>
<!-- Vscode -->
<a margin="20" href="https://code.visualstudio.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/vsc.png" alt="vscode"></a>
<!-- Visual studio -->
<a margin="20" href="https://visualstudio.microsoft.com/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/vs.png" alt="visuals"></a>
<br/>
<!-- Datagrip -->
<a margin="20" href="https://www.jetbrains.com/datagrip/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/datag.png" alt="datagrip"></a>
<!-- Pycharm -->
<a margin="20" href="https://www.jetbrains.com/pycharm/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/pyc.png" alt="pycharm"></a>
<!-- Webstorm -->
<a margin="20" href="https://www.jetbrains.com/webstorm" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/webs.png" alt="webstorm"></a>
<!-- InteliJ -->
<a margin="20" href="https://www.jetbrains.com/idea/" target="_blank"><img margin="20px" height="20" src="https://github.com/brightkut/brightkut/blob/main/int.png" alt="intelij"></a></div>


<br/>
<br/>
<br/>
<br/>

###

<h3 align="center" > <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30" height="30" style="margin-right: 50px;">Contact  me 🤝 </h3>
<p align="center">

 <div align="center"  class="icons-social" style="margin-left: 10px;">
        <a style="margin-left: 10px;"  target="_blank" href="https://www.linkedin.com/in/disorn-thitikornkovit-565526186/">
			<img src="https://img.icons8.com/doodle/40/000000/linkedin--v2.png"></a>
        <a style="margin-left: 10px;" target="_blank" href="https://github.com/brightkut">
		<img src="https://img.icons8.com/doodle/40/000000/github--v1.png"></a>
        <a style="margin-left: 10px;" target="_blank" href="https://www.instagram.com/brighteloy/">
			<img src="https://img.icons8.com/doodle/40/000000/instagram-new--v2.png"></a>
		<a style="margin-left: 5px;" target="_blank" href="https://github.com/brightkut/brightkut/blob/main/resumev8.pdf">
					<img src="https://img.icons8.com/plasticine/40/000000/resume.png" ></a>
</div>


<br/>

### Reference:

https://github.com/100rabhcsmc

https://github.com/sarath-pm

https://github.com/abdoachhoubi

------
Credit: [brightkut](https://github.com/brightkut)
Last Edited on: 24/01/2023