### Hi there 👋

![Profile views counter](https://caneco.dev/github-profile-view-counter.svg)

#### I'm a Full-Stack Developer working in Lisbon, Portugal.

- 🏢 I'm currently working at **Medicare Portugal**
- ⚙️ I use daily: `.php`, `.js`, `.html`, `.css`, `.svg`, `.psd`, `.ai`
- 🌍 I'm mostly active within the **Laravel Community**
- 💅 Designed: @pestphp, [NorthMeetsSouth.audio](https://www.northmeetssouth.audio), [ThenPing.me](https://thenping.me), [HappydDev.fm](https://www.happydev.fm), etc…
- 🌱 Learning all about **Open Source**
- 🎙 Currently hosting [Laravel Live Portugal – Season 2](https://www.youtube.com/playlist?list=PLLXPV3-YsvzTSuYYr6EkIQyvbzbvIQjkh)
- 💬 Ping me about **design**, **branding**, **laravel**, **development**, **design thinking**
- 📫 Reach me: [twitter.com/caneco](https://twitter.com/caneco)
- ⚡️ Fun fact: I'm a huge fan of Harry Potter

-----
Credits: [caneco](https://github.com/caneco)

Last Edited on: 30/08/2020