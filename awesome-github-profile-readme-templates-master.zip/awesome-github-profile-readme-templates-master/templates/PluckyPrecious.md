# Hola!:wave: Mucho Gusto.:blush:

<img src="https://github.com/PluckyPrecious/PluckyPrecious/blob/9565cf79245d4787c6fcade1bda5ceb011d287cd/F25AC92B-312E-4CD7-A884-AD0FDEC99A80.jpeg" alt="banner that says Kelechi Precious Nwachukwu - code newbie always. content curator. contributing for good alongside an oil paint illustration of Kelechi"> 
Hi, I'm Kelechi, a Project Manager with Finance background & love for anything Data or Tech. Open-source documentation & translation contributor, working on using data for good, big team player. Python is my first language, loving Markdown too. Igbo native, cartoon freak, chocolate, good food, and karaoke.


## More About Me:woman:

:purple_heart: Kind people are my kinda people

:100: Radical for Jesus

:star: Uniquely naive tho independent

:apple: Beginner mindset (**open to learning**)

:sparkles: Child at heart (**i see the world as magical**)


>*I love to race in where angels fear to tread. Committed to face fears & overcome them. In order to escape any feeling of being stuck, i often travel.*


## Find me around the WWW🌎:

<p align="center"> 


- Contributing on: <a href="https://github.com/PluckyPrecious"><img src="https://img.shields.io/github/followers/PluckyPrecious.svg?label=GitHub&style=social" alt="GitHub"></a>


- Trying to be up to good on: <a href="https://twitter.com/PluckyPrecious"><img src="https://img.shields.io/twitter/follow/PluckyPrecious?label=Twitter&style=social" alt="Twitter"></a> 


- Lazy curating pluckyspiration on: <a href="https://www.youtube.com/channel/UC2-U73E-uyf_lNCDO0yENlQ?view_as=subscriber">YouTube</a> or <a href="https://pluckys.home.blog/2019/11/01/the-journey-begins/">WordPress</a>

-----
Credits: [PluckyPrecious](https://github.com/PluckyPrecious)

Last Edited on: 30/08/2020