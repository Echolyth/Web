<img src="https://b4dcat404.github.io/images/two.gif" width="100%"/>

# 🖖 Hey! Welcome to my profile <img align="right" src="https://komarev.com/ghpvc/?username=b4dcat404&style=flat-square&color=blueviolet">

I'm a front-end developer!

I am 24 years old, I live and work in Russia Crimea Evpatoria. 
I've been doing IT since I was 16, I've been creating websites for 3 years, now I'm actively studying game development and game design. 

I also study Python and write bots for Telegram

If you want you can visit my [portfolio](https://b4dcat404.github.io/)

## 👨🏻‍💻 About me

<br>

<img src="https://website-crimea.ru/wp-content/uploads/github/message.gif" width="300px" align="right">

- 🌎 I'm from Russia / Crimea
- 👨🏻‍💻 Love programming and gaming
- 🧠 I like to learn something new
- 💭 I dream of developing the IT sector in my region
- 📧 Reach me via vitalii.redka.dev@gmail.com

<br>
<br>
<br>
<br>
<br>

## 💻 Tech stack
<div style="display: inline-block">
<img src="https://github.com/b4dcat404/devicon/blob/master/icons/html5/html5-original.svg" width="32px">
<img src="https://raw.githubusercontent.com/b4dcat404/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/css3/css3-original.svg" width="32px">
<img src="https://github.com/b4dcat404/devicon/blob/master/icons/mysql/mysql-original.svg" width="32px">
<img src="https://github.com/b4dcat404/devicon/blob/master/icons/unity/unity-original.svg" width="32px">
<img src="https://github.com/b4dcat404/devicon/blob/master/icons/linux/linux-original.svg" width="32px">
<img src="https://github.com/b4dcat404/devicon/blob/master/icons/python/python-original.svg" width="32px">
</div>

<br>

## 📊 Take a look in my stats

<a href="https://github.com/b4dcat404" >
<img height="160em" src="https://github-readme-stats.vercel.app/api?username=b4dcat404&show_icons=true&bg_color=282A36&title_color=DD6387&icon_color=BD93F9&text_color=fff&border_color=fff" />
<img height="160em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=b4dcat404&layout=compact&bg_color=282A36&title_color=DD6387&icon_color=BD93F9&text_color=fff&border_color=fff" />
</a>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

---

<p align="center" > 
  <i>Thanks for passing by</i><br><br>
  <i>Feel free to connect with me</i><br><br>
  <a href="https://twitter.com/b4dcat404" target="_blank">
  <code><img alt="My Twitter" width="32" src="https://website-crimea.ru/wp-content/uploads/github/twitter.svg" /></code>
</a>
<a href="https://instagram.com/b4dcat404" target="_blank">
<code><img alt="My Instagram" width="32" src="https://website-crimea.ru/wp-content/uploads/github/instagram.svg" /></code>
</a>
<a href="mailto:vitalii.redka.dev@gmail.com" target="_blank">
<code><img alt="My Mail" width="32" src="https://website-crimea.ru/wp-content/uploads/github/gmail.svg" /></code>
</a>
</p>
------
Credit: [username](https://github.com/b4dcat404)
Last Edited: 11/02/2022