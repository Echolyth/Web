<h2 align="center"> Hi 👋 , I'm Israt Jahan Khan <br/></h2> 
<h3 align="center">Also known as "Ipty" to other people. <br> <br>
  <a href="https://github.com/IsratIJK" target="_blank">
    <img alt="GitHub followers" src="https://img.shields.io/github/followers/IsratIJK?label=Github%20followers&style=for-the-badge">
  </a> <br> <br>
  <a href="https://github.com/IsratIJK" target="_blank">
    <img src="https://komarev.com/ghpvc/?username=IsratIJK&label=Views&color=brightgreen&style=flat-square" alt="views on github" />
  </a>
  </h3>   
                             
                    
<details align="center"> 
  <summary>GitHub Trophies 🏆</summary>
<p align="center">
  <a href="https://github.com/ryo-ma/github-profile-trophy" target="_blank">
    <img src="https://github-profile-trophy.vercel.app/?username=IsratIJK&theme=gruvbox"/>
  </a>
</p>
</details>
  
  
    
  
<details>
   <summary>Github Stats of me:</summary>
<div align="center">
<a href="#"><img src="https://github-readme-stats.vercel.app/api?username=IsratIJK&show_icons=true&count_private=true&theme=radical" width="350" height="250" ></a>
  <br>
<a href="#"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=IsratIJK&layout=compact&theme=radical" width="350" height="250" ></a>

</div>
</details> 
 

 
Let me introduce myself  :girl: 

- 🔭 I’m currently working on [CP](https://en.wikipedia.org/wiki/Competitive_programming#:~:text=The%20aim%20of%20competitive%20programming,mathematical%20or%20logical%20in%20nature). Sometimes I try to work on some short personal projects of mine.
- :art: <b>Hobby:</b> Attending in [CP](https://en.wikipedia.org/wiki/Competitive_programming#:~:text=The%20aim%20of%20competitive%20programming,mathematical%20or%20logical%20in%20nature), watching anime series, movies, English TV series and so on. I was a bookworm earlier even though I don't read that much nowadays. :disappointed: I love tech-related stuff whether it could be :iphone: or :computer: related stuff although I keep decent knowledge regarding :computer:  
- :high_brightness: <b>Special quality:</b> <br>
        :beginner: Problem Solving <br>
        :beginner: Tech Enthusiasts <br>
        :beginner: Web Designing <br>
        :beginner: Strategy <br>

<h2 align="center">

 Technologies and Languages 
</h2>

![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)
![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)
![Whatsapp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)
![Messenger](https://img.shields.io/badge/Messenger-00B2FF?style=for-the-badge&logo=messenger&logoColor=white)
![Zoom](https://img.shields.io/badge/Zoom-2D8CFF?style=for-the-badge&logo=zoom&logoColor=white)
![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)
![Stack Overflow](https://img.shields.io/badge/Stack_Overflow-FE7A16?style=for-the-badge&logo=stack-overflow&logoColor=white)
![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![HTML](https://img.shields.io/badge/HTML-239120?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS-239120?&style=for-the-badge&logo=css3&logoColor=white)
![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white)
![Microsoft Exel](https://img.shields.io/badge/Microsoft_Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white)
![Microsoft Powerpoint](https://img.shields.io/badge/Microsoft_PowerPoint-B7472A?style=for-the-badge&logo=microsoft-powerpoint&logoColor=white)
![Microsoft Office](https://img.shields.io/badge/Microsoft_Office-D83B01?style=for-the-badge&logo=microsoft-office&logoColor=white)
![Microsoft word](https://img.shields.io/badge/Microsoft_Word-2B579A?style=for-the-badge&logo=microsoft-word&logoColor=white)
![Microsoft](https://img.shields.io/badge/Microsoft-666666?style=for-the-badge&logo=microsoft&logoColor=white)



<h2 align="center">
My Current Workstation Specification </h2>

<div align="center">
  
![Laptop](https://img.shields.io/badge/Windows-ASUS-0078D6?style=for-the-badge&logo=windows&logoColor=white) 
<br>

![CPU](https://img.shields.io/badge/Intel-Core_i3_4th-0071C5?style=for-the-badge&logo=intel&logoColor=white)
 
  


</div>


















---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

<div align="center">
  


  
  <img align="center" a href='https://archiveprogram.github.com/'><img src='https://raw.githubusercontent.com/acervenky/animated-github-badges/master/assets/acbadge.gif' width='40' height='40'></a>

 ### ⚡️ Fun fact about me: ✨ I love coding+learning+sleeping✨ 
 


<h2>Connect with me!</h2>
 
[<img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white" />](https://www.linkedin.com/in/IsratIJK/) [<img src = "https://img.shields.io/badge/twitter-%2320A1F1.svg?&style=for-the-badge&logo=twitter&logoColor=white">](https://twitter.com/IsratIJK/)  







<br> <br>
🌟 STAR THE REPOS IF YOU LIKE 🌟

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=IsratIJK" alt="IsratIJK" /></p>

</div>









---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


- :snowflake: If you want to check my profile of CP related various Online Judges, then: <br>
:star: [Codeforces](https://codeforces.com/profile/IsratIJK) <br>
:star: [Toph](https://toph.co/u/IsratIJK) <br>
:star: [HackerRank](https://www.hackerrank.com/IsratIJK) <br>
:star: [URI](https://www.urionlinejudge.com.br/judge/en/profile/436965) <br>
:star: [Dimik OJ](https://dimikoj.com/users/6472/IsratIJK) <br>
:star: [CodeMarshal](https://algo.codemarshal.org/users/IsratIJK) <br>
<i>Many more are coming soon...</i> :cupid:

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
<br><br>


<div align="center">
  

![IsratIJK's wakatime stats](https://github-readme-stats.vercel.app/api/wakatime?username=IsratIJK&layout=compact&theme=radical)


</div>


<p align="center">

<a href="https://github.com/FahimFBA/github-readme-twitter">
<img align="center" src="https://github-readme-twitter.gazf.vercel.app/api?id=IsratIJK&layout=wide&show_reply=off&show_retweet=off" />
</a>

</p>


----------
Credit: [IsratIJK](https://github.com/IsratIJK)
Last Edited on: 03/09/2021
