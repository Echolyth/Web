<img align="left" src="https://orhun.dev/img/crow.png">

[![pgp](https://img.shields.io/badge/pgp-0xB928720AEC532117-313131?style=flat-square&labelColor=313131&color=313131)](https://orhun.dev/orhun.gpg)   
[![twitter](https://img.shields.io/badge/-@orhunp__-313131?style=flat-square&labelColor=313131&logo=twitter&logoColor=white&color=313131)](https://twitter.com/orhunp_)  
[![linkedin](https://img.shields.io/badge/-@orhunp-313131?style=flat-square&labelColor=313131&logo=LinkedIn&logoColor=white&color=313131)](https://www.linkedin.com/in/orhunp/)  
[![patreon](https://img.shields.io/badge/-@orhunp-313131?style=flat-square&labelColor=313131&logo=Patreon&logoColor=white&color=313131)](https://patreon.com/orhunp)

Passionate about **GNU/Linux**. Likes to write code. **Scroll down!**

-----
Credits: [orhun](https://github.com/orhun)

Last Edited on: 30/08/2020