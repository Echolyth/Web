# <h1 align="center">Hi, I'm <a href="https://github.com/Kathryn-Jie">Yi Jie<a><img src="https://github.com/Kathryn-Jie/Kathryn-Jie/blob/main/wave.gif" width="60px" /></h1>
    
<p align="center">
    <img width="200" src="https://github.com/Kathryn-Jie/Kathryn-Jie/blob/main/kathryn.png">
</p>

<div>
<strong>About Me:</strong><br>
💻 I’m currently working as an intern at Nicholas Actuarial Solutions<br>
📚 I’m a final year Actuarial Science undergraduate in University of Malaya<br>
📈 I experienced in Actuarial Statistics, Data Analysis, Data Visualization and Forecasting<br>
🏆 My certifications: 
<ul>
  <li>SOA: Exam FM, Exam P</li>
  <li>ICDL: Cloud Computing, Digital Marketing, Spreadsheets, Presentation and Online Collaboration</li>
  <li>Coursera: SAS Visual Business Analytics</li>
  <li>DataCamp: Shiny Fundamentals, Statistics Fundamentas and Spreadsheet Fundamentals with R Track</li>
</ul>
📫 Reach me at <a href="mailto:yijie0575@gmail.com">yijie0575@gmail.com</a><br>
😄 Find me on <a href="https://www.linkedin.com/in/yi-jie-tey/">Linkedin</a><br><br><br>

<strong>📊 My Github Stats :</strong><br><br>
![GitHub stats](https://github-readme-stats.vercel.app/api?username=Kathryn-Jie&show_icons=true&count_private=true&include_all_commits=true&theme=radical)<br>
<img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=Kathryn-Jie&theme=radical&hide_border=true"/><br><br>

<strong>💡 My Languages :</strong><br><br>
<img src="https://img.shields.io/badge/-R-lightgrey?style=plastic"/>
<img src="https://img.shields.io/badge/-HTML-lightgrey?style=plastic"/>
<img src="https://img.shields.io/badge/-CSS-lightgrey?style=plastic"/>
<img src="https://img.shields.io/badge/-C++-lightgrey?style=plastic"/><br>
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Kathryn-Jie&langs_count_private=true&theme=radical&card_width=445)<br><br>

<strong>🚀 My Latest Update :</strong><br><br>
[![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=Kathryn-Jie&repo=Kathryn-Jie&theme=radical)](https://github.com/Kathryn-Jie/Kathryn-Jie)
</div>

------
Credit: [Kathryn-Jie](https://github.com/Kathryn-Jie)
Last Edited on: 15/4/2021
