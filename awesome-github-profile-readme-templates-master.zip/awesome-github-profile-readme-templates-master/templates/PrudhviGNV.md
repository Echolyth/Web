### Hey 👋, I'm [Prudhvi Garapati!](https://github.com/PrudhviGNV)


<a href="https://www.linkedin.com/in/prudhvignv/">
  <img align="left" alt="Prudhvi's LinkdeIN" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://www.instagram.com/prudhvi_gnv/">
  <img align="left" alt="Prudhvi's Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />
</a>
<br />
 <a href="https://prudhvignv.github.io/" align="left" > My portfolio : prudhvignv.github.io </a> 
<br />
<br />

Hi, I'm Prudhvi GNV,a passionate engineering graduate specialised in computer science. Enthusiastic in Data science and web development. Looking for opportunities to work in Reputed Innovative Companies. Fascinated in solving problems and accepting new challenges.Intern at TheSmartbridge in Machine learning and deep learning and experienced real time Industry projects.


"Imagination is more important than knowledge. For knowledge is limited, whereas imagination embraces the entire world, stimulating progress, giving birth to evolution." 



 <img align="right" height="300px" width= "320px" alt="GIF" src="https://media.giphy.com/media/CVtNe84hhYF9u/giphy.gif" />

**Talking about Education/Skills:**

- 🎓 Graduating in 2021 from Gudlavalleru Enginering College
-  python 
-  Data Science , Machine Learning, Deep Learning and Web development
- Python , Java, JavaScript, C, C#
-  Html, CSS, Java Script, JQuery, BootStrap, React
-  DBMS, MySQL, MongoDB
-  libraries: Keras, OpenCv, Scikit-learn, Numpy, Pandas, Matplotlib

- 💬 Ask me about anything, I am happy to help
- 📫 How to reach me: prudhvi.gnv@gmail.com

&nbsp;


![Prudhvi's github stats](https://github-readme-stats.vercel.app/api?username=PrudhviGNV&show_icons=true&hide_border=true)

:pushpin: Star and Fork this [README](https://github.com/PrudhviGNV/PrudhviGNV) :pencil:

💻 Recent projects in which I have contributed in my [github](https://github.com/PrudhviGNV/)


<a href="https://github.com/PrudhviGNV/FacialEmotionRecognition-usingCNN">
    <img align="right" src="https://github-readme-stats.vercel.app/api/pin/?username=PrudhviGNV&repo=FacialEmotionRecognition-usingCNN" />
</a>

<a href="https://github.com/PrudhviGNV/FaceRecognisationBasedAttendence">
  <img align="right" src="https://github-readme-stats.vercel.app/api/pin/?username=PrudhviGNV&repo=FaceRecognisationBasedAttendence" />
</a>

<a href="https://github.com/PrudhviGNV/pathFinderVisualizer">
  <img align="left" src="https://github-readme-stats.vercel.app/api/pin/?username=PrudhviGNV&repo=pathFinderVisualizer" />
</a>

<a href="https://github.com/PrudhviGNV/SpeechEmotionRecognization">
  <img align="right" src="https://github-readme-stats.vercel.app/api/pin/?username=PrudhviGNV&repo=SpeechEmotionRecognization" />
</a>

-----
Credits: [PrudhviGNV](https://github.com/PrudhviGNV)

Last Edited on: 30/08/2020