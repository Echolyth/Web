<h1 style="text-align: center;margin-bottom: 5px;">Hi, I'm Marcelo Garbin<img src="https://raw.githubusercontent.com/iampavangandhi/iampavangandhi/master/gifs/Hi.gif" alt="Hi" style="width: 30px;margin-left: 10px;"></h1>
<h3 style="font-size: 1.2rem; text-align: center;margin: 0 0 20px 0;">Full stack web developer, Laravel, Vue.js and all the technology behind it...</h3>

<ul style="list-style: none;">
<li>:seedling: I'm in constant learning (currently Inertia.js with Laravel 8 / Nuxt / Tailwind CSS)</li>
<li>:octocat: I’m looking to collaborate projects that make use of <strong>PHP, JavaScript, HTML, CSS, Translations</strong></li>
<li>:brazil: From Rio Grande do Sul, Rodeio Bonito, Brazil</li>
<li>:rocket: I'm looking for new projects and work opportunities</li>
<li>:metal: Let's Rock n' Roll and Code, baby.</li>
</ul>
<div align="center">
<h3>Contact Me :handshake:</h3>
<a href="https://github.com/garbinmarcelo" target="_blank"><img src="https://img.shields.io/badge/-Marcelo_Garbin-black?logo=github&style=flat-square" alt="github"/></a>
<a href="https://www.linkedin.com/in/garbinmarcelo" target="_blank"><img src="https://img.shields.io/badge/-Marcelo_Garbin-blue?logo=linkedin&style=flat-square" alt="linkedin"></a>
<a href="https://www.instagram.com/garbinmarcelo" target="_blank"><img src="https://img.shields.io/badge/-Marcelo_Garbin-pink?logo=instagram&textColor=white&style=flat-square" alt="instagram"/></a>
<a href="https://twitter.com/marcelo_garbin" target="_blank"><img src="https://img.shields.io/badge/-marcelo__garbin-blue?logo=twitter&logoColor=white&style=flat-square" alt="twitter"/></a>
<a href="mailto:marcelo@garbin.dev"><img src="https://img.shields.io/badge/-marcelo@garbin.dev-white?logo=thunderbird&style=flat-square" alt="twitter"/></a>
<br/><br/>
<a href="https://www.buymeacoffee.com/garbinmarcelo" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="45" width="170" alt="garbinmarcelo" /></a>
</div>


---

<div align="center">
<h2>Knowledge Base :hammer_and_wrench:</h2>

<h3>Back-end & Front-end</h3>

<a href="https://php.net" target="_blank"><img src="https://img.shields.io/badge/PHP-white.svg?style=for-the-badge&logo=php&logoColor=777BB4" alt="php"/></a>
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"><img src="https://img.shields.io/badge/JavaScript-white.svg?style=for-the-badge&logo=javascript&logoColor=#F7DF1E" alt="javascript"/></a>

<a href="https://laravel.com" target="_blank"><img src="https://img.shields.io/badge/Laravel-white.svg?style=for-the-badge&logo=laravel&logoColor=FF2D20" alt="laravel"/></a>
<a href="https://vuejs.org/" target="_blank"><img src="https://img.shields.io/badge/-Vue.js-white?logo=vuedotjs&style=for-the-badge" alt="vuejs"/></a>
<a href="https://nuxtjs.org/" target="_blank"><img src="https://img.shields.io/badge/-Nuxt.js*-white?logo=nuxtdotjs&logoColor=00DC82&style=for-the-badge" alt="nuxtjs"/></a>
<a href="https://inertiajs.com/" target="_blank"><img src="https://img.shields.io/badge/-Inertia.js*-white?logo=inertiadotjs&logoColor=00DC82&style=for-the-badge" alt="inertiadotjs"/></a>

<a href="https://getbootstrap.com/" target="_blank"><img src="https://img.shields.io/badge/-Bootstrap-white?logo=bootstrap&logoColor=7952B3&style=for-the-badge" alt="bootstrap"/></a>
<a href="https://tailwindcss.com/" target="_blank"><img src="https://img.shields.io/badge/-tailwind css*-white?logo=tailwindcss&logoColor=06B6D4&style=for-the-badge" alt="tailwindcss"/></a>
<a href="https://html.spec.whatwg.org/multipage/" target="_blank"><img src="https://img.shields.io/badge/-HTML-white?logo=html5&style=for-the-badge" alt="html5"/></a>
<a href="https://www.w3.org/Style/CSS" target="_blank"><img src="https://img.shields.io/badge/-CSS-white?logo=css3&logoColor=1572B6&style=for-the-badge" alt="css3"/></a>
<a href="https://jquery.com/" target="_blank"><img src="https://img.shields.io/badge/-jquery-white?logo=jquery&logoColor=0769AD&style=for-the-badge" alt="jquery"/></a>


<a href="https://getcomposer.org/" target="_blank"><img src="https://img.shields.io/badge/-composer-white?logo=composer&logoColor=885630&style=for-the-badge" alt="composer"/></a>
<a href="https://webpack.js.org/" target="_blank"><img src="https://img.shields.io/badge/-webpack-white?logo=webpack&logoColor=8DD6F9&style=for-the-badge" alt="webpack"/></a>
<a href="https://gulpjs.com/" target="_blank"><img src="https://img.shields.io/badge/-gulp-white?logo=gulp&logoColor=CF4647&style=for-the-badge" alt="gulp"/></a>
<a href="https://www.npmjs.com/" target="_blank"><img src="https://img.shields.io/badge/-npm-white?logo=npm&logoColor=CB3837&style=for-the-badge" alt="npm"/></a>
<a href="https://yarnpkg.com/" target="_blank"><img src="https://img.shields.io/badge/-yarn-white?logo=yarn&logoColor=2C8EBB&style=for-the-badge" alt="yarn"/></a>

<a href="https://wordpress.com/" target="_blank"><img src="https://img.shields.io/badge/-wordpress-white?logo=wordpress&logoColor=21759B&style=for-the-badge" alt="wordpress"/></a>
<a href="https://www.opencart.com/" target="_blank"><img src="https://img.shields.io/badge/-opencart-white?logo=opencart&logoColor=21759B&style=for-the-badge" alt="opencart"/></a>
<a href="https://www.algolia.com/" target="_blank"><img src="https://img.shields.io/badge/-algolia*-white?logo=algolia&logoColor=5468FF&style=for-the-badge" alt="algolia"/></a>

<h3>Database</h3>

<a href="https://www.postgresql.org/" target="_blank"><img src="https://img.shields.io/badge/-postgresql-white?logo=postgresql&logoColor=4169E1&style=for-the-badge" alt="postgresql"/></a>
<a href="https://www.mysql.com/" target="_blank"><img src="https://img.shields.io/badge/-mysql-white?logo=mysql&logoColor=4479A1&style=for-the-badge" alt="mysql"/></a>
<a href="https://mariadb.org/" target="_blank"><img src="https://img.shields.io/badge/-mariadb-white?logo=mariadb&logoColor=003545&style=for-the-badge" alt="mariadb"/></a>
<a href="https://redis.io/" target="_blank"><img src="https://img.shields.io/badge/-redis*-white?logo=redis&logoColor=DC382D&style=for-the-badge" alt="redis"/></a>

<h3>Testing</h3>

<a href="https://phpunit.de/" target="_blank"><img src="https://img.shields.io/badge/-phpunit-white?logo=php&logoColor=777BB4&style=for-the-badge" alt="phpunit"/></a>
<a href="https://pestphp.com/" target="_blank"><img src="https://img.shields.io/badge/-pestphp*-white?logo=pestphp&logoColor=C21325&style=for-the-badge" alt="pestphp"/></a>
<a href="https://jestjs.io/" target="_blank"><img src="https://img.shields.io/badge/-jest*-white?logo=jest&logoColor=C21325&style=for-the-badge" alt="jest"/></a>

<h3>Version Control & CI/CD</h3>
<a href="https://git-scm.com/" target="_blank"><img src="https://img.shields.io/badge/-git-white?logo=git&logoColor=F05032&style=for-the-badge" alt="git"/></a>
<a href="https://github.com/" target="_blank"><img src="https://img.shields.io/badge/-github-white?logo=github&logoColor=181717&style=for-the-badge" alt="github"/></a>
<a href="https://github.com/features/actions" target="_blank"><img src="https://img.shields.io/badge/-github_actions*-white?logo=githubactions&logoColor=2088FF&style=for-the-badge" alt="githubactions"/></a>
<a href="https://gitlab.com/" target="_blank"><img src="https://img.shields.io/badge/-gitlab-white?logo=gitlab&logoColor=FCA121&style=for-the-badge" alt="gitlab"/></a>
<a href="https://bitbucket.org/" target="_blank"><img src="https://img.shields.io/badge/-bitbucket-white?logo=bitbucket&logoColor=0052CC&style=for-the-badge" alt="bitbucket"/></a>
<a href="https://www.docker.com/" target="_blank"><img src="https://img.shields.io/badge/-docker-white?logo=docker&logoColor=2496ED&style=for-the-badge" alt="docker"/></a>

<h3>Cloud & Hosting</h3>

<a href="https://aws.amazon.com" target="_blank"><img src="https://img.shields.io/badge/-amazon_aws-white?logo=amazonaws&logoColor=232F3E&style=for-the-badge" alt="amazonaws"/></a>
<a href="https://cpanel.net/" target="_blank"><img src="https://img.shields.io/badge/-cpanel-white?logo=cpanel&logoColor=FF6C2C&style=for-the-badge" alt="cpanel"/></a>
<a href="https://httpd.apache.org/" target="_blank"><img src="https://img.shields.io/badge/-apache-white?logo=apache&logoColor=D22128&style=for-the-badge" alt="apache"/></a>
<a href="https://www.nginx.com/" target="_blank"><img src="https://img.shields.io/badge/-nginx-white?logo=nginx&logoColor=009639&style=for-the-badge" alt="nginx"/></a>

<h3>IDE & Tools</h3>

<a href="https://www.jetbrains.com/phpstorm/" target="_blank"><img src="https://img.shields.io/badge/-phpstorm-white?logo=phpstorm&logoColor=000000&style=for-the-badge" alt="phpstorm"/></a>
<a href="https://www.sublimetext.com/" target="_blank"><img src="https://img.shields.io/badge/-sublime_text-white?logo=sublimetext&logoColor=FF9800&style=for-the-badge" alt="sublimetext"/></a>
<a href="https://www.pgadmin.org/" target="_blank"><img src="https://img.shields.io/badge/-pgadmin-white?logo=postgresql&logoColor=4169E1&style=for-the-badge" alt="pgadmin"/></a>
<a href="https://www.mysql.com/products/workbench/" target="_blank"><img src="https://img.shields.io/badge/-mysql_workbench-white?logo=mysql&logoColor=4479A1&style=for-the-badge" alt="mysql"/></a>
<a href="https://www.phpmyadmin.net/" target="_blank"><img src="https://img.shields.io/badge/-phpmyadmin-white?logo=phpmyadmin&logoColor=6C78AF&style=for-the-badge" alt="phpmyadmin"/></a>
<a href="https://www.postman.com/" target="_blank"><img src="https://img.shields.io/badge/-postman-white?logo=postman&logoColor=FF6C37&style=for-the-badge" alt="postman"/></a>
<a href="https://filezilla-project.org/filezilla_pro.php" target="_blank"><img src="https://img.shields.io/badge/-filezilla-white?logo=filezilla&logoColor=BF0000&style=for-the-badge" alt="filezilla"/></a>
<a href="https://www.microsoft.com/en-us/windows" target="_blank"><img src="https://img.shields.io/badge/-windows-white?logo=windows&logoColor=0078D6&style=for-the-badge" alt="windows"/></a>
<a href="https://github.com/microsoft/terminal" target="_blank"><img src="https://img.shields.io/badge/-windows_terminal-white?logo=windowsterminal&logoColor=4D4D4D&style=for-the-badge" alt="windowsterminal"/></a>
<a href="https://ubuntu.com/" target="_blank"><img src="https://img.shields.io/badge/-ubuntu-white?logo=ubuntu&logoColor=E95420&style=for-the-badge" alt="ubuntu"/></a>
<a href="https://trello.com/" target="_blank"><img src="https://img.shields.io/badge/-trello-white?logo=trello&logoColor=0052CC&style=for-the-badge" alt="trello"/></a>
<a href="https://slack.com/" target="_blank"><img src="https://img.shields.io/badge/-slack-white?logo=slack&logoColor=4A154B&style=for-the-badge" alt="slack"/></a>
</div>

<small><strong>*</strong> Studying and improving technology skills.</small>

---

<div align="center">
<h2 style="margin: 5px 10px;">GitHub Statistics :chart_with_upwards_trend:</h2> 
<div style="display: flex; align-items: center; justify-content: center;">

[![](https://github-readme-stats.vercel.app/api?username=garbinmarcelo&show_icons=true&theme=tokyonight&hide_border=true&locale=en)](https://github.com/garbinmarcelo)
[![](https://github-readme-streak-stats.herokuapp.com/?user=garbinmarcelo&theme=tokyonight&hide_border=true)](https://github.com/garbinmarcelo)

</div>
</div>

<div align="center">

![](https://komarev.com/ghpvc/?username=garbinmarcelo&style=flat-square)

</div>


------

Credit: [garbinmarcelo](https://github.com/garbinmarcelo)

Last Edited on: 18/10/2021