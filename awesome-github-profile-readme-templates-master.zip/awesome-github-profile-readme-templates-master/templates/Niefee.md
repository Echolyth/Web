### Hi there 👋


<div align="center">
    <img src="https://raw.githubusercontent.com/Niefee/niefee/master/assets/fly.webp" height="120px" />
</div>

<br/>

- 🌱 My name is niefee, I am Chinese, welcome to my GitHub home page
- ⚡ I know HTML
- 😄 And a little bit of CSS, JavaScript, ReactJS, NodeJS, Vue.js, etc.
- 💖 Love the beautiful code and photos
- 🔥 One is never too old to learn.

<br/>

<p align="center">
    <img style="height:10rem;" src="https://github-readme-stats.vercel.app/api?username=Niefee&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&show_icons=true&theme=radical" />
    <img style="height:10rem;" src="https://github-readme-streak-stats.herokuapp.com/?user=Niefee&theme=radical&show_icons=true&border=e4e2e2" />
</p>

<div align="center">
    <picture align="center">
      <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/Niefee/niefee/master/assets/github-contribution-grid-snake.svg">
      <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Niefee/niefee/master/assets/github-contribution-grid-snake.svg">
      <img alt="github contribution grid snake animation" src="https://raw.githubusercontent.com/Niefee/niefee/master/assets/github-contribution-grid-snake.svg">
    </picture>
</div>


<p align="center"> 
  <div align="center">Visitor count</div>
  <div align="center">
    <img src="https://profile-counter.glitch.me/Niefee/count.svg"/>
  </div> 
</p>

------

Credit: [Niefee](https://github.com/Niefee)
Last Edited on 03/02/2023
