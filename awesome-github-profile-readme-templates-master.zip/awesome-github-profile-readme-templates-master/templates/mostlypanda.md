<h1 align="center">Hi 👋, I'm Sarthak Mittal</h1>
<h3 align="center">Enthusiastic full stack MERN developer from India.</h3>


<h3 align="left">Connect with me:</h3>
<p align="left">

    <a href="https://linkedin.com/in/sarthak mittal" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg" alt="sarthak mittal" height="30" width="40" /></a>

    <a href="https://medium.com/@sarthakmittal1461" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/medium.svg" alt="@sarthakmittal1461" height="30" width="40" /></a>

</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> 

    <a href="https://www.cprogramming.com/" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> 

    <a href="https://www.w3schools.com/cpp/" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> 

    <a href="https://www.djangoproject.com/" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/django/django-original.svg" alt="django" width="40" height="40"/> </a> 

    <a href="https://expressjs.com" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/express/express-original-wordmark.svg" alt="express" width="40" height="40"/> </a> 

    <a href="https://git-scm.com/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> </a> 

    <a href="https://heroku.com" target="_blank"> <img src="https://www.vectorlogo.zone/logos/heroku/heroku-icon.svg" alt="heroku" width="40" height="40"/> </a> 

    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> 

    <a href="https://www.mongodb.com/" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/> </a>

    <a href="https://nodejs.org" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/> </a>

    <a href="https://www.php.net" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/php/php-original.svg" alt="php" width="40" height="40"/> </a> 

    <a href="https://www.python.org" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a>

    <a href="https://reactjs.org/" target="_blank"> <img src="https://devicons.github.io/devicon/devicon.git/icons/react/react-original-wordmark.svg" alt="react" width="40" height="40"/> </a> 

</p>

<img src='https://github-readme-stats.vercel.app/api?username=mostlypanda&show_icons=true&theme=radical&count_private=true'/>

<img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=mostlypanda&count_private=true&theme=radical" alt="mostlypanda" />

<div style="flex: 33.33%; padding: 5px;">
    <img align="center" src="https://github-readme-stats.vercel.app/api/wakatime?username=mostlypanda&count_private=true&theme=radical" alt="mostlypanda" /></div>
</div>

-----
Credits: [mostlypanda](https://github.com/mostlypanda)

Last Edited on: 01/01/2021