
<h1>Bonjour. I'm Kirill & I ❤️ code.</h1>
<h4>Currently i work at private orders but i always open for cooperation | Write to me using: <a href="mailto:git.xcaq@gmail.com">Email <img src="https://camo.githubusercontent.com/5bf17041186bbc591a286709593ee76baf2e4711/68747470733a2f2f6564656e742e6769746875622e696f2f537570657254696e7949636f6e732f696d616765732f7376672f676d61696c2e737667" width="10"></a></h4>
<h5>⏰ 29 Saturday, 06:12 | Latest follower – <a href="https://github.com/AhsanParadise/" target="_blank">AhsanParadise</a> 👋</h5>
<hr>
<h2>📝 Statistics: </h2>
<table>
  <tr>
    <td valign="top">
      <h3>Most starred repos: </h3>
            <h6>⭐️&nbsp;&nbsp;&nbsp;3&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;771 – <a href='https://github.com/xcaq/xcaq'>xcaq</a></h6> 
      <h6>⭐️&nbsp;&nbsp;&nbsp;2&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;49 – <a href='https://github.com/xcaq/SpotiTransfer'>SpotiTransfer</a></h6> 
      <h6>⭐️&nbsp;&nbsp;&nbsp;8&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;247 – <a href='https://github.com/xcaq/spotify-to-vk'>spotify-to-vk</a></h6> 
    </td>
    <td valign="top">
      <h3>My stack: </h3>
      <h6>📒&emsp;<a href="https://github.com/xcaq?tab=repositories&q=&type=&language=python">Python</a> ( Middle )</h6>
      <h6>📗&emsp;<a href="https://github.com/xcaq?tab=repositories&q=&type=&language=c%23">C#</a> ( Junior )</h6>
      <h6>📘&emsp;<a href="https://github.com/xcaq?tab=repositories&q=&type=&language=golang">Golang</a> ( Intern )</h6>
      </td>
     <td valign="top">
      <h3>New repositories: </h3>
           <h6>⭐️&nbsp;&nbsp;&nbsp;0&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;93 – <a href='https://github.com/xcaq/CSES'>CSES</a></h6> 
      <h6>⭐️&nbsp;&nbsp;&nbsp;2&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;49 – <a href='https://github.com/xcaq/SpotiTransfer'>SpotiTransfer</a></h6> 
      <h6>⭐️&nbsp;&nbsp;&nbsp;3&nbsp;&nbsp;|&nbsp;&nbsp;👁&nbsp;&nbsp;&nbsp;771 – <a href='https://github.com/xcaq/xcaq'>xcaq</a></h6> 
        </td>
  </tr>
</table>
<h2>📊 Weekly development breakdown: </h2>
<table>
                <tr>
                    <td width=215px;>
                        Python
                    </td>
                    <td>
                        11 hrs 43 mins
                    </td>
                    <td>
                        ██████░░░░&nbsp;&nbsp;(67.01 %)
                    </td>
                </tr>
                <tr>
                    <td width=220px;>
                        CSS
                    </td>
                    <td width=145px;>
                        3 hrs 8 mins
                    </td>
                    <td width=230px;>
                        █░░░░░░░░░&nbsp;&nbsp;(17.92 %)
                    </td>
                </tr>
                <tr>
                    <td width=220px;>
                        HTML
                    </td>
                    <td width=145px;>
                        2 hrs 27 mins
                    </td>
                    <td width=230px;>
                        █░░░░░░░░░&nbsp;&nbsp;(14.08 %)
                    </td>
                </tr></table>
<hr>
<h4 align="center">Other – <a href='http://gothboy.me' target="_blank">gothboy.me</a><h4>
    
-----
Credits: [xcaq](https://github.com/xcaq)

Last Edited on: 30/08/2020