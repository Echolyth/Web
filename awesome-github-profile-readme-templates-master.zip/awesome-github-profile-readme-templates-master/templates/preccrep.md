<!---
preccrep/preccrep is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->

```

      ___         ___           ___           ___           ___           ___           ___           ___   
     /  /\       /  /\         /  /\         /  /\         /  /\         /  /\         /  /\         /  /\  
    /  /::\     /  /::\       /  /:/_       /  /:/        /  /:/        /  /::\       /  /:/_       /  /::\ 
   /  /:/\:\   /  /:/\:\     /  /:/ /\     /  /:/        /  /:/        /  /:/\:\     /  /:/ /\     /  /:/\:\
  /  /:/~/:/  /  /:/~/:/    /  /:/ /:/_   /  /:/  ___   /  /:/  ___   /  /:/~/:/    /  /:/ /:/_   /  /:/~/:/
 /__/:/ /:/  /__/:/ /:/___ /__/:/ /:/ /\ /__/:/  /  /\ /__/:/  /  /\ /__/:/ /:/___ /__/:/ /:/ /\ /__/:/ /:/ 
 \  \:\/:/   \  \:\/:::::/ \  \:\/:/ /:/ \  \:\ /  /:/ \  \:\ /  /:/ \  \:\/:::::/ \  \:\/:/ /:/ \  \:\/:/  
  \  \::/     \  \::/~~~~   \  \::/ /:/   \  \:\  /:/   \  \:\  /:/   \  \::/~~~~   \  \::/ /:/   \  \::/   
   \  \:\      \  \:\        \  \:\/:/     \  \:\/:/     \  \:\/:/     \  \:\        \  \:\/:/     \  \:\   
    \  \:\      \  \:\        \  \::/       \  \::/       \  \::/       \  \:\        \  \::/       \  \:\  
     \__\/       \__\/         \__\/         \__\/         \__\/         \__\/         \__\/         \__\/  


```

![preccrep GitHub stats](https://github-readme-stats.vercel.app/api/top-langs/?username=preccrep&show_icons=true&theme=radical)
![preccrep GitHub stats](https://github-readme-stats.vercel.app/api?username=preccrep&show_icons=true&theme=tokyonight)

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Monaco&size=30&duration=7000&background=E4E4E400&lines=Hey+I'm+preccrep!;I'm+a+CS+student.;I+love+coding.;A+big+fan+of+anime...)](https://git.io/typing-svg)

<p align="center">
  <a href="https://twitter.com/preccrep"><img alt="Twitter Follow" src="https://img.shields.io/twitter/follow/preccrep?color=a2c4c9&logoColor=ffe599&style=for-the-badge">
  <a href="https://www.preccrep.com/"><img alt="PersonalBlog" src="https://img.shields.io/static/v1?label=personalblog&message=preccrep&color=f4cccc&style=for-the-badge">
  <a href="https://www.cnblogs.com/preccrep"><img alt="CNBlog" src="https://img.shields.io/static/v1?label=cnblog&message=preccrep&color=b4a7d6&style=for-the-badge">
</p>

    I'm a student currently studying computer science.


**I'm a Night 🦉** 

```text
🌞 Morning    57 commits     ████░░░░░░░░░░░░░░░░░░░░░   17.65% 
🌆 Daytime    87 commits     ██████░░░░░░░░░░░░░░░░░░░   26.93% 
🌃 Evening    42 commits     ███░░░░░░░░░░░░░░░░░░░░░░   13.0% 
🌙 Night      137 commits    ██████████░░░░░░░░░░░░░░░   42.41%
```
📅 **I'm Most Productive on Thursday** 

```text
Monday       42 commits     ███░░░░░░░░░░░░░░░░░░░░░░   13.0% 
Tuesday      52 commits     ████░░░░░░░░░░░░░░░░░░░░░   16.1% 
Wednesday    57 commits     ████░░░░░░░░░░░░░░░░░░░░░   17.65% 
Thursday     80 commits     ██████░░░░░░░░░░░░░░░░░░░   24.77% 
Friday       25 commits     ██░░░░░░░░░░░░░░░░░░░░░░░   7.74% 
Saturday     41 commits     ███░░░░░░░░░░░░░░░░░░░░░░   12.69% 
Sunday       26 commits     ██░░░░░░░░░░░░░░░░░░░░░░░   8.05%
```

<!--START_SECTION:colourise-->

<p align=center>
<img src="https://img.shields.io/badge/-C++-80953D?style=for-the-badge&logo=c%2b%2b"/>
<img src="https://img.shields.io/badge/-Java-235548?style=for-the-badge&logo=java"/>
<img src="https://img.shields.io/badge/-Swift-B32D51?style=for-the-badge&logo=swift"/>
<img src="https://img.shields.io/badge/-Python-92B9D8?style=for-the-badge&logo=python" />
<img src="https://img.shields.io/badge/-JavaScript-00FFFF?style=for-the-badge&logo=javascript"/>
<img src="https://img.shields.io/badge/-HTML5-523D95?style=for-the-badge&logo=html5"/>
<img src="https://img.shields.io/badge/-CSS-E19F8A?style=for-the-badge&logo=css3"/>
<!--END_SECTION:colourise-->

<div align="center"> <img src="https://github-readme-streak-stats.herokuapp.com/?user=preccrep&theme=radical" /> </div>

<div align="center"> <img src="https://github-profile-trophy.vercel.app/?username=preccrep" /> </div>

<div align="center"> <img src="https://visitor-badge.glitch.me/badge?page_id=preccrep" /> </div>

<div align="center"> <img src="https://activity-graph.herokuapp.com/graph?username=preccrep&theme=xcode" /> </div>

-----

Credits: [preccrep](https://github.com/preccrep)

Last Edited on: 15/06/2022
