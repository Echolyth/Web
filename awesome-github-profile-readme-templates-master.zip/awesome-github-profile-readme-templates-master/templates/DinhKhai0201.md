

## Hi there.  I'm Khai

### I'm a Software Engineer from Vietnam
### Details about me
- I’m Khai. I’m a web, mobile and blockchain developer living in Da Nang, Vietnam. I am a fan of technology, programming, and writing. I’m also interested in sports and photography.
- 😊 Pronouns: **he/him**
- 🌟 About me: <https://about.me/dinhkhai0201>
- 🎨 Portfolio: <https://standardresume.co/r/dinhkhai0201>
- 💻 Actively contributing to Open Source GitHub repositories and also focusing on my professional projects
- 📧 You can reach out to me by searching "dinhkhai0201" on [@Google](https://github.com/google.com)

<section align="center">
    <h3>Contact with me on:</h3>
    <div>
        <a href="https://linkedin.com/in/dinhkhai0201"><img width="30px" height="30px" src="icons/linkedin.svg" alt="LinkedIn"></a>
        &nbsp;
        <a href="mailto://ndkhai.dev@gmail.com"><img width="30px" height="30px" src="icons/gmail.svg" alt="Email"></a>
        &nbsp;
        <a href="https://twitter.com/dinhkhai0201"><img width="30px" height="30px" src="icons/x.svg" alt="Twitter"></a>
        &nbsp;
        <a href="https://t.me/dinhkhai0201"><img width="30px" height="30px" src="icons/telegram.svg" alt="Telegram"></a>
        &nbsp;
    </div>
</section>

<section align="center">
    <h3>Personal stats:</h3>
    <section align="center">
      <p><b>dinhkhai0201's Profile Overview</b></p>
     <a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FDinhKhai0201&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits%2Fviews&edge_flat=false"/></a>
    </section>
    <br/>
    <div>
        <img width="400px" src="https://github-readme-stats.vercel.app/api?username=dinhkhai0201" alt="dinhkhai0201's GitHub stats"/>
        <img width="400px" src="https://github-readme-streak-stats.herokuapp.com/?user=dinhkhai0201&" alt="dinhkhai0201's GitHub streak"/>
    </div>
</section>

------
Credits : [DinhKhai0201](https://github.com/DinhKhai0201)

Last Edited on: 19/02/2024

